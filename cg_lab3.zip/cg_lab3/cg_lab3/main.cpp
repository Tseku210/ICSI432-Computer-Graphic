#include <GLUT/glut.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <array>

using namespace std;

float  x, y;
bool flag = true;
bool line = false;
bool one_line = false;
bool ll = false;
bool mouse_down = false;
float x_arr[50], y_arr[50];
float x_one_arr[2], y_one_arr[2];
float next_x, next_y;
int j;
int i;

void mouse(int button, int state, int mousex, int mousey)
{
    if (line) {
        if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
            flag = true;
            x_arr[i] = mousex;
            y_arr[i] = 500 - mousey;
            i++;
            //mouse_down = (state == GLUT_DOWN);
            //printf("x: %f", x);
            //printf("\ny: %f", y);
        }
    } else if (ll) {
        if (button == GLUT_LEFT_BUTTON) {
            x = mousex;
            y = 500 - mousey;
            printf("\nxa: %f", x);
            printf("\nya: %f", y);
            mouse_down = (state == GLUT_DOWN);
        }
        if (mouse_down) {
            next_x = mousex;
            next_y = 500 - mousey;
            printf("\nxm: %f", x);
            printf("\nym: %f", y);
        }


    } else if (one_line) {
        if (j == 2) {
            j = 0;
            x_one_arr[0] = 0;
            x_one_arr[1] = 0;
            y_one_arr[0] = 0;
            y_one_arr[1] = 0;
        }
        else if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
            flag = true;
            x_one_arr[j] = mousex;
            y_one_arr[j] = 500 - mousey;
            j++;
        }
    } else {
        if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
            flag = true;
            x = mousex;
            y = 500 - mousey;
            //mouse_down = (state == GLUT_DOWN);
            printf("x: %f", x);
            printf("\ny: %f", y);
        }
    }
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
    switch(key) {
    case 'l':
        line = true;
        one_line = false;
        ll = false;
        break;
    case 'd':
        line = false;
        one_line = false;
        ll = false;
        break;
    case 'a':
        one_line = true;
        line = false;
        ll = false;
        break;
    case 'b':
        ll = true;
        one_line = false;
        line = false;
        break;
    case 'q':
        glClear(GL_COLOR_BUFFER_BIT);
        glutPostRedisplay();
        break;
    }
}

void display(void)
{
    float theta;
    glViewport(0, 0, 500, 500);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 500.0, 0.0, 500.0, 1.0, -1.0);
    glColor3f(1.0f, 0.0f, 0.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    //glEnable(GL_LINE_SMOOTH);
    if (flag) {
        if (line) {
            glBegin(GL_LINE_STRIP);
            for (int k = 0; k < i; k++)
            {
                glVertex2f(x_arr[k], y_arr[k]);
            }
            glEnd();
        } else if (ll) {
            printf("\nx: %f", x);
            printf("\ny: %f", y);
            printf("\nxn: %f", next_x);
            printf("\nyn: %f", next_y);
            glBegin(GL_LINES);
            glVertex2f(x, y);
            glVertex2f(next_x, next_y);
            glEnd();
        } else if (one_line) {
            glBegin(GL_LINES);
            for (int k = 0; k < j; k++)
            {
                glVertex2f(x_one_arr[k], y_one_arr[k]);
            }
            glEnd();
        } else {
            glBegin(GL_POLYGON);
            for (int i = 0; i < 360; i++) {
                theta = i * 3.142 / 180;
                glVertex2f(x + 3 * cos(theta),
                           y + 3 * sin(theta));
            }
            //glVertex2d(x, y);
            glEnd();
        }
    }
    glFlush();
}

int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutCreateWindow("Paint");

    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
}
